package queue;
import java.util.ArrayList;


public class ArraylistQueue<E> implements Queue<E>, Cloneable {

	//	Attribut

	ArrayList<E> arrayList ;

	//	Konstruktor

	public ArraylistQueue() {
		arrayList= new ArrayList<E>();
	}


	// Methoden	

	public void enqueue(E o) {
		//		verwendet implementierte methode von Klasse ArrayList
		arrayList.add(arrayList.size(),o);
	}

	public E dequeue() {
		if (!empty()) {
			//			remove(index) Rueckgabe (->) entferntes Element
			return arrayList.remove(0);
		} else {
			System.err.println("dequeue on empty list");
			return null;
		}
	}

	public int size() {
		return arrayList.size();
	}

	public boolean empty() {
		//		greift auf size Implementation dieser Klasse zurueck
		return this.size()==0;
	}

	public String toString() {
		//		formatiert ausgabe, erleichtert debugging
		String s = "[ ";
		for (int i = 0; i < arrayList.size(); i++) {
			s += arrayList.get(i) + " , ";
		}
		return s + " ]";
	}
	
}

//	public ArraylistQueue(Queue<? extends Cloneable> q) {	
//		//implementation wird nachgeliefert
////		q.dequeue().clone();
//	}
