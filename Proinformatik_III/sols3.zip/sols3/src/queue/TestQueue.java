package queue;

public class TestQueue {

	public static void main(String[] args) {
//		ArrayQueue a = new ArrayQueue();
//		a.dequeue();
//		a.enqueue(new Object());
//		a.enqueue(new Object());
//		System.out.println(a);
//		System.out.println(a.size());
//		System.out.println(a.dequeue());
//		System.out.println(a);
		TestQueue.randTest();
	}
	
	public static void randTest(){
		Queue<Object> q = new ArrayQueue();
//		Queue<Object> q = new ArrayListQueue();
		int inList = 0;
//		Schleife zaehlt in einser Schritten bis tausend
		for (int i = 0; i < 1000; i++) {
			System.out.println(q.size());
			System.out.println(inList);
			if (q.empty()) {
				q.enqueue(new Object());
				inList++;
			} else {
//				Queue ist voll
				if (inList == 100) {
					q.dequeue();
					inList--;
				} else {
//					zufaellige auswahl 0(hinzufuegen) 1(entfernen)
					if (Math.round(Math.random())==0) {
						q.enqueue(new Object());
						inList++;
					} else {
						q.dequeue();
						inList--;
					}
				}
			}
		}
	}
}
