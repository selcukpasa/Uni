package queue;

public class ArrayQueue implements Queue {

//	Attribute
	
	Object[] a;
	int size;
	
//	Konstruktoren
	
	public ArrayQueue(int i) {
		a = new Object[i];
		size = 0;
	}
	
	public ArrayQueue() {
//		ruft bereits implementierten Konstruktor auf 
		this(100);
	}
	
//	Methoden
	
	public void enqueue(Object o) {
		if (size!=a.length) {
//			fuegt an position 0 oder hinter zuletzt hinzugefuegtem Element den uebergebenen Parameter o an
			a[size++]=o;			
		} else {
			System.err.println("enqueue on full list ");
		}
		
	}

	public Object dequeue() {
		if (!empty()) {
//			merkt Objekt an Index 0
			Object res = a[0];
//			verschiebt alle Objekte ab Zelle 1 um eine Stelle nach links
			for (int i = 1; i < size; i++) {
				a[i-1]=a[i];
			}
			size--;
			return res;			
		}
		else {
			System.err.println("dequeue on empty list ");
			return null;
		}
	}

	public int size() {
		return size;
	}

	public boolean empty() {
		return size==0;
	}

	public String toString() {
		String s = "[ ";
		for (int i = 0; i < size; i++) {
			s += a[i] + " , ";
		}
		return s + " ]";
	}
	
}
