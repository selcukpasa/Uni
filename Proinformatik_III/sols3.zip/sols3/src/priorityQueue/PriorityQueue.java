package priorityQueue;

public interface PriorityQueue {

	void enqueue(Comparable o);
	Comparable extractMin();
	int size();
	boolean empty();
}
