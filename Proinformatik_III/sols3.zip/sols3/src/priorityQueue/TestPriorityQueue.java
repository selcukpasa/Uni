package priorityQueue;

public class TestPriorityQueue {
	public static void main(String[] args) {
		ArrayPriorityQueue a = new ArrayPriorityQueue();
		//		System.out.println(a.extractMin());
		//		System.out.println(a.extractMin());
		//		System.out.println(a.extractMin());
		a.enqueue(new Integer(5));
		a.enqueue(new Integer(6));
		a.enqueue(new Integer(3));
		a.enqueue(new Integer(1));
		System.out.println(a);
		//		System.out.println(a.extractMin());
		//		System.out.println(a.extractMin());
		//		System.out.println(a.extractMin());
	}
}
