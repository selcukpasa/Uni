package priorityQueue;

public class ArrayPriorityQueue implements PriorityQueue {

	Comparable[] a;
	int size;

	public ArrayPriorityQueue(int maxSize) {
//		leeres array mit maxSize vielen Plaetzen
		a = new Comparable[maxSize];
		size = 0;
	}

	public ArrayPriorityQueue() {
//		ruft den Konstruktor auf mit maxSize = 100
		this(100);
	}
	
//	Methoden

	public void enqueue(Comparable o) {
		if (size != a.length) {
//		absteigend sortierte Liste
//		findet passende Stelle fuer o
//		verschiebt alle kleineren Elemente um eins nach rechts
//		vorgehensweise aehnlich zu insertionsort
			int i;
			for (i = 0; i < size; i++) {
				if (a[i].compareTo(o)<0) {
					break;
				} 
			}
			for (int j = size; i < j; j--) {
				a[j]=a[j-1];
			}
			a[i]=o;
			size++;
		} else {
			System.err.println("array full in enqueue");
		}
		
	}
	
	

	public Comparable extractMin() {
		// entfernt letztes Element
		if (!empty()) {
			return a[--size];
		} else {
			System.err.println("queue empty extractMin");
			return null;
		}
	}

	public int size() {
		return size;
	}

	public boolean empty() {
		return size() == 0;
	}

	
	public String toString() {
		String s = "[ ";
		for (int i = 0; i < size; i++) {
			s += a[i] + " , ";
		}
		return s + " ]";
	}
	
}
